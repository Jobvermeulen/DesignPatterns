﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave3
{
    class Employee
    {
        private string Name;
        public int Number; 

        public Employee(string Name, int Number)
        {
            this.Name = Name;
            this.Number = Number;
        }

        public override string ToString()
        {
            return $"{Name} ({Number})";
        }
    }
}
