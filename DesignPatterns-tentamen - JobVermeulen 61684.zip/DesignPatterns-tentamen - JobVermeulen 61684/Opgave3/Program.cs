﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave3
{
    class Program
    {
        public static Employee Ronald;
        public static Employee Kevin;

        static void Main(string[] args)
        {
            Ronald = new Employee("Ronald", 11290);
            Kevin = new Employee("Kevin", 10671);

            ClockIn();
            ClockOut();

            Console.ReadLine();
        }

        public static void ClockIn()
        {
            PrintHeader("[ ClockIn ]");

            RegistrationSystem instance = RegistrationSystem.GetInstance();

            instance.ClockIn(Ronald);
            instance.ClockIn(Kevin);
            instance.ClockIn(Ronald);

            Console.WriteLine();
        }

        public static void ClockOut()
        {
            PrintHeader("[ ClockOut ]");

            RegistrationSystem instance = RegistrationSystem.GetInstance();

            instance.ClockOut(Kevin);
            instance.ClockOut(Ronald);
            instance.ClockOut(Kevin);
        }

        private static void PrintHeader(string text)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(text);
            Console.ResetColor();
        }
    }
}
