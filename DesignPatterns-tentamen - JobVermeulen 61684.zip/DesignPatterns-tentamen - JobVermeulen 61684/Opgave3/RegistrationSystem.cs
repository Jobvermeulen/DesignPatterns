﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave3
{
    class RegistrationSystem
    {
        public Dictionary<int, Employee> NrOfClockedInEmployees = new Dictionary<int, Employee>();
        private static RegistrationSystem uniqueInstance;

        private RegistrationSystem() { }

        public static RegistrationSystem GetInstance()
        {
            if (uniqueInstance == null)
                uniqueInstance = new RegistrationSystem();

            return uniqueInstance;
        }

        public void ClockIn(Employee user)
        {
            if (!NrOfClockedInEmployees.ContainsKey(user.Number))
            {
                NrOfClockedInEmployees.Add(user.Number, user);
                Console.WriteLine($"Employee {NrOfClockedInEmployees[user.Number].ToString()} clocked in.");
            }
            else
            {
                Console.WriteLine($"Employee {NrOfClockedInEmployees[user.Number].ToString()} already clocked in!");
            }
        }

        public void ClockOut(Employee user)
        {
            if (NrOfClockedInEmployees.ContainsKey(user.Number))
            {
                Console.WriteLine($"Employee {NrOfClockedInEmployees[user.Number].ToString()} clocked out.");
                NrOfClockedInEmployees.Remove(user.Number);
            }
            else
            {
                Console.WriteLine($"Employee {user.ToString()} not clocked in!");

            }

        }

    }
}
