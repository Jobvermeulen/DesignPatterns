﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave4
{
    class GPSController : IGPSController
    {
        private IGPSSysteem gps;

        public GPSController(IGPSSysteem gps)
        {
            this.gps = gps;
        }

        public void UpdatePositie()
        {
            gps.UpdatePositie();
        }
    }
}
