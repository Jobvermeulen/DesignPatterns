﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave4
{
    class GlobalPositioningSysteem : IGPSSysteem
    {
        private int breedteGraad;
        private int lengteGraad;
        private Random rnd;
        private List<IGPSObserver> displays ;

        public int HuidigeBreedteGraad { get; set; }
        public int huidigeLengteGraad { get; set; }

        public GlobalPositioningSysteem()
        {
            breedteGraad = 5;
            lengteGraad = 52;
            rnd = new Random();
            displays = new List<IGPSObserver>();
        }

        public void UpdatePositie()
        {
            HuidigeBreedteGraad =  rnd.Next(breedteGraad, 10);
            huidigeLengteGraad =  rnd.Next(lengteGraad, 60);

            UpdateSchermen();
        }

        public void SchermToevoegen(IGPSObserver observer)
        {
            displays.Add(observer);
        }

        public void SchermVerwijder(IGPSObserver observer)
        {
            displays.Remove(observer);
        }

        private void UpdateSchermen()
        {
            foreach(IGPSObserver observer in displays)
            {
                observer.update(huidigeLengteGraad, HuidigeBreedteGraad);
            }
        }
    }
}
