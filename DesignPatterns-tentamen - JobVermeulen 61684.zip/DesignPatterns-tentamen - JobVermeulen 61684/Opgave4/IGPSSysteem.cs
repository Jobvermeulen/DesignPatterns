﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave4
{
    interface IGPSSysteem
    {
        void SchermToevoegen(IGPSObserver observer);
        void SchermVerwijder(IGPSObserver observer);
        void UpdatePositie();
    }
}
