﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave4
{
    class StandaardScherm : IGPSObserver
    {
        private IGPSSysteem gpsSysteem;

        public StandaardScherm(IGPSSysteem gpsSysteem)
        {
            this.gpsSysteem = gpsSysteem;
            gpsSysteem.SchermToevoegen(this);
        }

        public void update(int HuidigeLengteGraad, int huidigeBreedteGraad)
        {
            Console.WriteLine($"[Standaard-scherm] LengteGraad: {HuidigeLengteGraad} , BreedteGraad: {huidigeBreedteGraad}");
        }
    }
}
