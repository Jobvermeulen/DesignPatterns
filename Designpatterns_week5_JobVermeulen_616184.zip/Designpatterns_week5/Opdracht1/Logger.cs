﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht1_Week1
{
    class Logger
    {
        private static Logger uniqueInstance;
        private int numberoflines;

        private Logger() { }

        public static Logger GetInstance()
        {
            if (uniqueInstance == null)
                uniqueInstance = new Logger();

            return uniqueInstance;
        }

        public void Log(string system, string work)
        {
            numberoflines++;
            Console.WriteLine("{0} - [{1}] {2}", numberoflines, system, work);
        }
    }
}
