﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht1_Week1
{
    class MainSystem
    {
        public MainSystem(){
            Logger instance = Logger.GetInstance();

            DoSomeMainWork(instance);
        }

        public void DoSomeMainWork(Logger instance)
        {
            instance.Log("MainSystem", "SubSystem");
            SubSystem subSystem = new SubSystem();
        }
    }
}
