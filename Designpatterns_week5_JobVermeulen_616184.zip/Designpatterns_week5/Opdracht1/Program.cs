﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht1_Week1
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger LoggerInstance = Logger.GetInstance();
            LoggerInstance.Log("Main", "starting");
            MainSystem mainSystem = new MainSystem();
            LoggerInstance.Log("Main", "Finished");

            Console.ReadLine();
        }
    }
}
