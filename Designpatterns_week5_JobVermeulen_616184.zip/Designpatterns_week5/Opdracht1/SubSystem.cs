﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht1_Week1
{
    class SubSystem
    {
        public SubSystem()
        {
            Logger LoggerInstance = Logger.GetInstance();
            DoSomeMoreWork(LoggerInstance);
            DoSomeWork(LoggerInstance);
        }

        public void DoSomeMoreWork(Logger LoggerInstance)
        {
            LoggerInstance.Log("SubSystem", "Doing some more work");
        }

        public void DoSomeWork(Logger LoggerInstance)
        {
            LoggerInstance.Log("SubSystem", "Doing some work");
        }
    }
}
