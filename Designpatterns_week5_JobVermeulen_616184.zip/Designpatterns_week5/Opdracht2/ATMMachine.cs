﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht2
{
    class ATMMachine
    {
        private int amountInMachine;
        private IATMState cardPresent;
        private IATMState correctPinCode;
        private IATMState noCard;
        private IATMState noCash;

        private IATMState machineState;

        public ATMMachine(int amountInMachine)
        {
            noCard = new NoCardState(this);
            cardPresent = new CardPresentState(this);
            correctPinCode = new CorrectPinState(this);
            noCash = new NoCashState(this);

            this.amountInMachine = amountInMachine;

            if (amountInMachine > 0)
                machineState = noCard;
            else
                machineState = noCash;
        }

        public void EnterPincode(int pincode)
        {
            machineState.EnterPincode(pincode);
        }

        public IATMState GetCardPresentState()
        {
            return cardPresent;
        }

        public IATMState GetCorrectPinState()
        {
            return correctPinCode;
        }

        public IATMState GetNoCardState()
        {
            return noCard;
        }

        public IATMState GetNoCashState()
        {
            return noCash;
        }

        public void InsertCard()
        {
            machineState.InsertCard();
        }

        public void RejectCard()
        {
            machineState.RejectCard();
        }

        public void SetAmountInMachine(int amountInMachine)
        {
            this.amountInMachine = amountInMachine;
        }

        public void SetMachineState(IATMState machineState)
        {
            this.machineState = machineState;
        }

        public void WithdrawCash(int amount)
        {
            if (amount < amountInMachine)
                machineState.WithdrawCash(amount);
            else
            {
                SetMachineState(GetNoCashState());
                machineState.WithdrawCash(amount);
            }
                

        }

    }
}
