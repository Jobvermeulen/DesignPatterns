﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht2
{
    class CardPresentState : IATMState
    {
        private ATMMachine machine;

        public CardPresentState(ATMMachine machine)
        {
            this.machine = machine;
        }

        public void EnterPincode(int pincode)
        {
            Console.WriteLine("U heeft de correcte pincode ingetoetst");
            machine.SetMachineState(machine.GetCorrectPinState());
        }

        public void InsertCard()
        {
            Console.WriteLine("U heeft al een kaart ingevoerd.");
        }

        public void RejectCard()
        {
            Console.WriteLine("Uw kaart is terug gegeven.");
            machine.SetMachineState(machine.GetNoCardState());
        }

        public void WithdrawCash(int amount)
        {
            Console.WriteLine("U moet eerst een hoeveelheid opgegeven.");
        }
    }
}
