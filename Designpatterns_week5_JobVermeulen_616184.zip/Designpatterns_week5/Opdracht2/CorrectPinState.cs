﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht2
{
    class CorrectPinState : IATMState
    {
        private ATMMachine machine;

        public CorrectPinState(ATMMachine machine)
        {
            this.machine = machine;
        }

        public void EnterPincode(int pincode)
        {
            Console.WriteLine("U heeft al een pincode ingevoerd.");

        }

        public void InsertCard()
        {
            Console.WriteLine("U heeft al een kaart ingevoerd.");
        }

        public void RejectCard()
        {
            Console.WriteLine("Uw kaart is terug gegeven.");
            machine.SetMachineState(machine.GetNoCardState());
        }

        public void WithdrawCash(int amount)
        {
            Console.WriteLine(amount + " is uitgegeven door de machine.");
            machine.SetAmountInMachine(-amount);
            RejectCard();
        }
    }
}
