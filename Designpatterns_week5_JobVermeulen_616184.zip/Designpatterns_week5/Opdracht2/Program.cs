﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        void Start()
        {
            ATMMachine machine = new ATMMachine(2000);

            machine.InsertCard();
            machine.RejectCard();

            Console.WriteLine();

            machine.InsertCard();
            machine.EnterPincode(1234);
            machine.WithdrawCash(1500);

            Console.WriteLine();

            machine.InsertCard();
            machine.EnterPincode(1234);
            machine.WithdrawCash(750);

            Console.ReadKey();
        }
    }
}
