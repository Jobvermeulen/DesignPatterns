﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeisngPatterns_week2_opdr3
{
    class FancyMP3Display : IObserver
    {
        public FancyMP3Display(ISubject player)
        {
            player.AddObserver(this);
        }

        public void Update(Nummer nummer)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Fancy mp3 player: " + nummer.titel + " van " + nummer.artiest + " <" + nummer.duurvanNummer + "> ");
            Console.ResetColor();

        }
    }
}
