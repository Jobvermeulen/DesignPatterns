﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeisngPatterns_week2_opdr3
{
    interface IObserver
    {
        void Update(Nummer nummer);
    }
}
