﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeisngPatterns_week2_opdr3
{
    class MP3Player : ISubject
    {
        public Nummer HuidigNummer { get; private set; }
        public List<Nummer> nummers;
        private List<IObserver> observers = new List<IObserver>();
        public Random rnd;

        public MP3Player(List<Nummer> nummers)
        {
            this.rnd = new Random();
            this.nummers = nummers;
            addNummer();
        }

        public void addNummer()
        {
            //voeg nummers toe aan list
            Nummer nummer1 = new Nummer("Wish you were here", "Pink Floyd", "03:12");
            nummers.Add(nummer1);
            Nummer nummer2 = new Nummer("Billionaire", "Bruno Mars", "03:33");
            nummers.Add(nummer2);
            Nummer nummer3 = new Nummer("Dazed and Confused", "Led Zeppeling", "04:00");
            nummers.Add(nummer3);
            Nummer nummer4 = new Nummer("Pull Up In Een Porsche", "Kraantje Pappie", "02:13");
            nummers.Add(nummer4);
            Nummer nummer5 = new Nummer("Euro's", "Kraantje Pappie", "03:14");
            nummers.Add(nummer5);
            Nummer nummer6 = new Nummer("Blah Blah Blah", "Armin van Buuren", "03:04");
            nummers.Add(nummer6);
            Nummer nummer7 = new Nummer("We write the story", "Avicii, B&B adn choir", "06:35");
            nummers.Add(nummer7);
        }

        public void NummerGewijzigd()
        {
            int r = rnd.Next(nummers.Count);
            HuidigNummer = nummers[r];

            NotifyObservers();
        }

        public void AddObserver(IObserver observer)
        {
            observers.Add(observer);
        }

        public void RemoveObserver(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void NotifyObservers()
        {
            foreach(IObserver observer in this.observers)
            {
                observer.Update(HuidigNummer);
            }
        }

    }
}
