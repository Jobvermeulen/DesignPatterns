﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeisngPatterns_week2_opdr3
{
    class Nummer
    {
        public string titel;
        public string artiest;
        public string duurvanNummer;

        public Nummer(string titel, string artiest, string duurvanNummer)
        {
            this.titel = titel;
            this.artiest = artiest;
            this.duurvanNummer = duurvanNummer;
        }

    }
}
