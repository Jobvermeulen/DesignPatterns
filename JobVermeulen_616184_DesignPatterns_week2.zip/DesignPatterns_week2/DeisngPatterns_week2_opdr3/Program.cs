﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeisngPatterns_week2_opdr3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Nummer> nummerlist = new List<Nummer>();
            // maak een MP3 player aan
            ISubject player = new MP3Player(nummerlist);

            // maak de displays aan
            IObserver mp3Display1 = new SimpleMP3Display(player);
            IObserver mp3Display2 = new FancyMP3Display(player);

            // zet player op een nieuw nummer
            // (aangezien er geen hardware is, doen we dat hier...)
            player.NummerGewijzigd();
            player.NummerGewijzigd();
            player.NummerGewijzigd();

            Console.ReadKey();
        }
    }
}
