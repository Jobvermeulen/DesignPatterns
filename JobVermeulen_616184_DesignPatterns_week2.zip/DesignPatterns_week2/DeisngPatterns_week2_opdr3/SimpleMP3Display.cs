﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeisngPatterns_week2_opdr3
{
    class SimpleMP3Display : IObserver
    {
        public SimpleMP3Display(ISubject player)
        {
            player.AddObserver(this);
        }

        public void Update(Nummer nummer)
        {
            Console.WriteLine("Simple mp3 player: " + nummer.artiest + " - " + "'" + nummer.titel + "'");
        }
    }
}
