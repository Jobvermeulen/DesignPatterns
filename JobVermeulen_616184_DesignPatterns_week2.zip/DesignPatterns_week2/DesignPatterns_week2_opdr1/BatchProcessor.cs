﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns_week2
{
    class BatchProcessor
    {
        public List<BigDataLoader> dataloaderItems { get; set; }

        public BatchProcessor(List<BigDataLoader> dataloaderItems)
        {
            this.dataloaderItems = dataloaderItems;
        }

        public void addLoader(BigDataLoader item)
        {
            dataloaderItems.Add(item);
        }

        public void startETLProcess()
        {
            foreach(BigDataLoader dataloaderItem in dataloaderItems)
            {
                dataloaderItem.etlProcess();
                Console.WriteLine();
            }
        }
    }
}
