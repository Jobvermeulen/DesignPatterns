﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns_week2
{
    abstract class BigDataLoader
    {
        public void etlProcess()
        {
            startETL();
            extractData();
            transfromData();
            loadingData();
            stopETL();
        }

        public void startETL()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("[ETL-proces started]");
            Console.ResetColor();
        }

        public void stopETL()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("[ETL-proces finished]");
            Console.ResetColor();
        }

        public abstract void extractData();
        public abstract void transfromData();
        public abstract void loadingData();
        
    }
}
