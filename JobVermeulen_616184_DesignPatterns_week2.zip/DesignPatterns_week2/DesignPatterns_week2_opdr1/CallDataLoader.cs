﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns_week2
{
    class CallDataLoader : BigDataLoader
    {
        public override void extractData()
        {
            Console.WriteLine("Extracting call data...");
        }

        public override void loadingData()
        {
            Console.WriteLine("Transforming call data...");
        }

        public override void transfromData()
        {
            Console.WriteLine("Loading call data...");
        }
    }
}
