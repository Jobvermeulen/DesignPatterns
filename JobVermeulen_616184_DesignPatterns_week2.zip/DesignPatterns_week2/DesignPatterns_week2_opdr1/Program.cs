﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns_week2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<BigDataLoader> dataloaderItems = new List<BigDataLoader>();
            BatchProcessor batchProcessor = new BatchProcessor(dataloaderItems);
            
            CallDataLoader callDataLoader = new CallDataLoader();
            SensorDataLoader sensorDataLoader = new SensorDataLoader();
            TwitterDataLoader twitterDataLoader = new TwitterDataLoader();

            batchProcessor.addLoader(callDataLoader);
            batchProcessor.addLoader(sensorDataLoader);
            batchProcessor.addLoader(twitterDataLoader);

            batchProcessor.startETLProcess();

            Console.ReadLine();
        }
    }
}
