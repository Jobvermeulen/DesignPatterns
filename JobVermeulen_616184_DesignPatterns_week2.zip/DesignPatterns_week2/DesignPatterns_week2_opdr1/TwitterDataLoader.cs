﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns_week2
{
    class TwitterDataLoader : BigDataLoader
    {
        public override void extractData()
        {
            Console.WriteLine("Extracting twitter data...");
        }

        public override void loadingData()
        {
            Console.WriteLine("Transforming twitter data...");
        }

        public override void transfromData()
        {
            Console.WriteLine("Loading twitter data...");
        }
    }
}
