﻿namespace DesignPatterns_week3
{
    partial class ControlPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.volgendstationBTN = new System.Windows.Forms.Button();
            this.nieuwdisplayBTN = new System.Windows.Forms.Button();
            this.terugstationBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // volgendstationBTN
            // 
            this.volgendstationBTN.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.volgendstationBTN.FlatAppearance.BorderSize = 0;
            this.volgendstationBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.volgendstationBTN.ForeColor = System.Drawing.Color.DarkOrange;
            this.volgendstationBTN.Location = new System.Drawing.Point(216, 235);
            this.volgendstationBTN.Name = "volgendstationBTN";
            this.volgendstationBTN.Size = new System.Drawing.Size(148, 68);
            this.volgendstationBTN.TabIndex = 0;
            this.volgendstationBTN.Text = "Volgend station";
            this.volgendstationBTN.UseVisualStyleBackColor = false;
            this.volgendstationBTN.Click += new System.EventHandler(this.volgendstationBTN_Click);
            // 
            // nieuwdisplayBTN
            // 
            this.nieuwdisplayBTN.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.nieuwdisplayBTN.FlatAppearance.BorderSize = 0;
            this.nieuwdisplayBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.nieuwdisplayBTN.ForeColor = System.Drawing.Color.DarkOrange;
            this.nieuwdisplayBTN.Location = new System.Drawing.Point(16, 520);
            this.nieuwdisplayBTN.Name = "nieuwdisplayBTN";
            this.nieuwdisplayBTN.Size = new System.Drawing.Size(112, 29);
            this.nieuwdisplayBTN.TabIndex = 0;
            this.nieuwdisplayBTN.Text = "Nieuw display";
            this.nieuwdisplayBTN.UseVisualStyleBackColor = false;
            this.nieuwdisplayBTN.Click += new System.EventHandler(this.nieuwdisplayBTN_Click);
            // 
            // terugstationBTN
            // 
            this.terugstationBTN.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.terugstationBTN.FlatAppearance.BorderSize = 0;
            this.terugstationBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.terugstationBTN.ForeColor = System.Drawing.Color.DarkOrange;
            this.terugstationBTN.Location = new System.Drawing.Point(216, 309);
            this.terugstationBTN.Name = "terugstationBTN";
            this.terugstationBTN.Size = new System.Drawing.Size(148, 68);
            this.terugstationBTN.TabIndex = 0;
            this.terugstationBTN.Text = "Terug reis";
            this.terugstationBTN.UseVisualStyleBackColor = false;
            this.terugstationBTN.Click += new System.EventHandler(this.terugstationBTN_Click);
            // 
            // ControlPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 561);
            this.Controls.Add(this.nieuwdisplayBTN);
            this.Controls.Add(this.terugstationBTN);
            this.Controls.Add(this.volgendstationBTN);
            this.Name = "ControlPanel";
            this.Text = "ControlPanel";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button volgendstationBTN;
        private System.Windows.Forms.Button nieuwdisplayBTN;
        private System.Windows.Forms.Button terugstationBTN;
    }
}