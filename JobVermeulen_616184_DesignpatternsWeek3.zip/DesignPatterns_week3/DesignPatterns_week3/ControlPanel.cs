﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesignPatterns_week3
{
    public partial class ControlPanel : Form, IControlPanel
    {
        private ITreinController TreinController { get; set; }

        public ControlPanel()
        {
            InitializeComponent();

            TreinController = new TreinController();
        }

        private void volgendstationBTN_Click(object sender, EventArgs e)
        {
            TreinController.VolgendStation();
        }

        private void nieuwdisplayBTN_Click(object sender, EventArgs e)
        {
            TreinController.NieuwDisplay();
        }

        private void terugstationBTN_Click(object sender, EventArgs e)
        {
            TreinController.TerugStation();
        }
    }
}
