﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns_week3
{
    public interface ITreinReis
    {
        void VolgendStation();
        void TerugStation();
        void AddObserver(ITreinDisplay treinDisplay);
        void RemoveObserver(ITreinDisplay treinDisplay);
    }
}
