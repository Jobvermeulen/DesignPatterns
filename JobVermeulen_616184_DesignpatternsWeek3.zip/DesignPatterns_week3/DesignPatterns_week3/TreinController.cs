﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesignPatterns_week3
{
    public class TreinController : ITreinController
    {
        private ITreinReis TreinReis { get; set; }

        public TreinController()
        {
            TreinReis = new TreinReis();
        }

        public void VolgendStation()
        {
            TreinReis.VolgendStation();
        }

        public void TerugStation()
        {
            TreinReis.TerugStation();
        }

        public void NieuwDisplay()
        {
            ITreinDisplay treinDisplay = new TreinDisplay(TreinReis);
            treinDisplay.Show();
        }

    }
}
