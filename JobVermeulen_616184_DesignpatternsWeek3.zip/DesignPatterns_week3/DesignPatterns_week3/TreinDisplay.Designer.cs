﻿namespace DesignPatterns_week3
{
    partial class TreinDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.HuigdigStationLBL = new System.Windows.Forms.Label();
            this.spoorLBL = new System.Windows.Forms.Label();
            this.huidigstationInfo = new System.Windows.Forms.Label();
            this.spoorInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // HuigdigStationLBL
            // 
            this.HuigdigStationLBL.AutoSize = true;
            this.HuigdigStationLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.HuigdigStationLBL.Location = new System.Drawing.Point(13, 13);
            this.HuigdigStationLBL.Name = "HuigdigStationLBL";
            this.HuigdigStationLBL.Size = new System.Drawing.Size(128, 24);
            this.HuigdigStationLBL.TabIndex = 0;
            this.HuigdigStationLBL.Text = "Huidig station:";
            // 
            // spoorLBL
            // 
            this.spoorLBL.AutoSize = true;
            this.spoorLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.spoorLBL.Location = new System.Drawing.Point(13, 49);
            this.spoorLBL.Name = "spoorLBL";
            this.spoorLBL.Size = new System.Drawing.Size(66, 24);
            this.spoorLBL.TabIndex = 0;
            this.spoorLBL.Text = "Spoor:";
            // 
            // huidigstationInfo
            // 
            this.huidigstationInfo.AutoSize = true;
            this.huidigstationInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.huidigstationInfo.Location = new System.Drawing.Point(147, 13);
            this.huidigstationInfo.Name = "huidigstationInfo";
            this.huidigstationInfo.Size = new System.Drawing.Size(0, 24);
            this.huidigstationInfo.TabIndex = 1;
            // 
            // spoorInfo
            // 
            this.spoorInfo.AutoSize = true;
            this.spoorInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.spoorInfo.Location = new System.Drawing.Point(147, 49);
            this.spoorInfo.Name = "spoorInfo";
            this.spoorInfo.Size = new System.Drawing.Size(0, 24);
            this.spoorInfo.TabIndex = 1;
            // 
            // TreinDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 161);
            this.Controls.Add(this.spoorInfo);
            this.Controls.Add(this.huidigstationInfo);
            this.Controls.Add(this.spoorLBL);
            this.Controls.Add(this.HuigdigStationLBL);
            this.Name = "TreinDisplay";
            this.Text = "TreinDisplay";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HuigdigStationLBL;
        private System.Windows.Forms.Label spoorLBL;
        private System.Windows.Forms.Label huidigstationInfo;
        private System.Windows.Forms.Label spoorInfo;
    }
}