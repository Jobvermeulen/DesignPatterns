﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesignPatterns_week3
{
    public partial class TreinDisplay : Form, ITreinDisplay
    {
        ITreinReis treinreis;

        public TreinDisplay(ITreinReis TreinReis)
        {
            InitializeComponent();

            treinreis = TreinReis;
            treinreis.AddObserver(this);
        }

        public void Update(Station station)
        {
            huidigstationInfo.Text = station.Naam;
            spoorInfo.Text = station.AankomstSpoor;
        }
    }
}
