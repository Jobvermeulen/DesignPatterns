﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns_week3
{
    public class TreinReis : ITreinReis
    {
        protected List<Station> stations;
        private int huidigStation;
        private List<ITreinDisplay> Observers;

        public TreinReis()
        {
            Observers = new List<ITreinDisplay>();

            Station Denhelder = new Station("Den Helder", "spoor 3", new DateTime(2019, 02, 19, 15, 34, 00), new DateTime(2019, 02, 19, 15, 34, 00));
            Station Alkmaar = new Station("Alkmaar", "spoor 5", new DateTime(2019, 02, 19, 16, 11, 00), new DateTime(2019, 02, 19, 16, 14, 00));
            Station AmsterdamCentraal = new Station("Amsterdam Centraal", "spoor 4", new DateTime(2019, 02, 19, 16, 51, 00), new DateTime(2019, 02, 19, 16, 54, 00));
            Station Nijmegen = new Station("Nijmegen", "spoor 4a", new DateTime(2019, 02, 19, 18, 17, 00), new DateTime(2019, 02, 19, 18, 17, 00));

            stations = new List<Station>();
            stations.Add(Denhelder);
            stations.Add(Alkmaar);
            stations.Add(AmsterdamCentraal);
            stations.Add(Nijmegen);

            huidigStation = 0;
        }

        public void VolgendStation()
        {
            if(huidigStation < stations.Count()-1)
            {
                huidigStation++;
                NotifyObservers();
            }           
        }

        public void TerugStation()
        {
            stations.Reverse();
            huidigStation = 0;
            NotifyObservers();
        }

        public void AddObserver(ITreinDisplay treinDisplay)
        {
            Observers.Add(treinDisplay);
            treinDisplay.Update(stations[huidigStation]);
        }

        public void RemoveObserver(ITreinDisplay treinDisplay)
        {
            Observers.Remove(treinDisplay);
        }

        private void NotifyObservers()
        {
            foreach(ITreinDisplay treinDisplay in Observers)
            {
                treinDisplay.Update(stations[huidigStation]);
            }
        }

        private Station GetFirstStation()
        {
            Station station = stations.First();
            return station;
        }

        private Station GetLastStation()
        {
            Station station = stations.Last();
            return station;
        }       
    }
}
