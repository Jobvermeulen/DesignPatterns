﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr1
{
    class Boek : BoekHandelItem
    {
        public string Auteur { get; set; }

        public Boek(string Auteur, string Titel, float Prijs, int Aantal): base (Titel, Prijs, Aantal)
        {
            this.Auteur = Auteur;
        }

        public override string returnEigenschappen()
        {
            string String = "Boek : Auteur: " + this.Auteur + " Titel: " + this.Titel + " Prijs: " + this.Prijs + " Aantal: " + this.Aantal;
            return String;
        }
    }
}
