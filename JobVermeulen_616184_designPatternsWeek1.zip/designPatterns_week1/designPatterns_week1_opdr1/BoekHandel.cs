﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr1
{
    class BoekHandel
    {
        public List<BoekHandelItem> items { get; set; }

        public BoekHandel(List<BoekHandelItem> items)
        {
            this.items = items;
        }

        public void VoegToe(BoekHandelItem item)
        {
            items.Add(item);
        }

        public void PrintOverzicht()
        {
            foreach(BoekHandelItem item in items)
            {
                Console.WriteLine(item.returnEigenschappen());
            }
            Console.ReadLine();
        }
    }
}
