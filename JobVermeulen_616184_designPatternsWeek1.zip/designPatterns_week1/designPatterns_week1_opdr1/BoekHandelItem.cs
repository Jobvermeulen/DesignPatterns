﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr1
{
    abstract class BoekHandelItem
    {
        public string Titel { get; set; }
        public float Prijs { get; set; }
        public int Aantal { get; set; }

        public BoekHandelItem(string Titel, float Prijs, int Aantal)
        { 
            this.Titel = Titel;
            this.Prijs = Prijs;
            this.Aantal = Aantal;
        }

        public abstract string returnEigenschappen();
    }
}
