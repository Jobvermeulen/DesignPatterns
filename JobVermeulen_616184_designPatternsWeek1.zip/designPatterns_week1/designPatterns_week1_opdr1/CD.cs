﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr1
{
    class CD : BoekHandelItem
    {
        public string Artiest { get; set; }

        public CD(string Artiest, string Titel, float Prijs, int Aantal) : base(Titel, Prijs, Aantal)
        {
            this.Artiest = Artiest;
        }

        public override string returnEigenschappen()
        {
            string String = "CD : Artiest: " + this.Artiest + " Titel: "  + this.Titel +  " Prijs: " + this.Prijs + " Aantal: " + this.Aantal;
            return String;
        }
    }
}
