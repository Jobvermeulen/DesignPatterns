﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<BoekHandelItem> items = new List<BoekHandelItem>();
            BoekHandel boekHandel = new BoekHandel(items);

            CD cd = new CD("Artiest van de CD", "Muziek waar je oren vanzelf van smelten", 100, 1);
            boekHandel.VoegToe(cd);
            Boek boek = new Boek("Gekke schrijver", "Het super dikke boek", 252, 123);
            boekHandel.VoegToe(boek);
            Weekblad weekblad = new Weekblad("woensdag", "Top Gear", 12, 600);
            boekHandel.VoegToe(weekblad);

            boekHandel.PrintOverzicht();
        }

    }
}
