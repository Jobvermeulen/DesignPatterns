﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr1
{
    class Weekblad : BoekHandelItem
    {
        public string UitgifteDag { get; set; }

        public Weekblad( string UitgifteDag, string Titel, float Prijs, int Aantal) : base(Titel, Prijs, Aantal)
        {
            this.UitgifteDag = UitgifteDag;
        }

        public override string returnEigenschappen()
        {
            string String = "Weekblad : UitgifteDag: " + this.UitgifteDag + " Titel: " + this.Titel + " Prijs: " + this.Prijs + " Aantal: " + this.Aantal;
            return String;
        }

    }
}
