﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr2
{
    interface IVliegbaar
    {
        void Opstijgen();
        void Vliegen();
        void Landen();
    }
}
