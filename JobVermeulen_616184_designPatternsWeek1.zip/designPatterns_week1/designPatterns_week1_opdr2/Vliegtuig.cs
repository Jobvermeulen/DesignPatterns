﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr2
{
    class Vliegtuig : IVliegbaar
    {
        public void Opstijgen()
        {
            Console.WriteLine("Vliegtuig aan het opstijgen...");
        }

        public void Vliegen()
        {
            Console.WriteLine("Vliegtuig aan het vliegen...");

        }

        public void Landen()
        {
            Console.WriteLine("Vliegtuig aan het landen...");
        }
    }
}
