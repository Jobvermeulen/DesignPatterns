﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr3
{
    public interface IPotloodSlijper
    {
        void Slijp(IPotlood potlood);
    }
}
