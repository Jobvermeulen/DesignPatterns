﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr3
{
    class Potlood : IPotlood
    {
        private int maxTeSchrijven; // aantal te schrijven karakters v/e geslepen potlood
        private int geschrevenKarakters; // aantal reeds geschreven karakters
        public Potlood(int maxTeSchrijven)
        {
            this.maxTeSchrijven = maxTeSchrijven;
        }

        //set toevoegen is inpricipe niet nodig
        //isScherp is undefinded dus standaard false
        public bool IsScherp { get; private set; }

        public void Schrijf(string boodschap)
        {
            foreach(char c in boodschap)
            {
                if(geschrevenKarakters < maxTeSchrijven)
                {
                    Console.Write(c);
                    geschrevenKarakters++;
                }
                else
                {
                    Console.Write("#");
                    IsScherp = false;
                }
            }
            Console.WriteLine();
        }

        public void NaGeslepen()
        {
            geschrevenKarakters = 0;
            IsScherp = true;
        }
    }
}
