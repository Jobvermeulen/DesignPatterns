﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace designPatterns_week1_opdr3
{
    class PotloodSlijper : IPotloodSlijper
    {
        public void Slijp(IPotlood potlood)
        {
            potlood.NaGeslepen();
        }
    }
}
